SAMBHAV - PERSONAL PORTFOLIO
WebDev I Lab Assignment 1

Folder structure:
sambhav_portfolio/
├── index.html
└── images/
    └── profile.svg

To run:
1. Open index.html in a web browser.
2. Click About, Projects, Skills, and Contact to test navigation.
3. Test the form fields. The form uses Sambhav's email address through mailto.

Note:
The project descriptions are beginner/practice projects because Sambhav currently
does not have completed major projects.
